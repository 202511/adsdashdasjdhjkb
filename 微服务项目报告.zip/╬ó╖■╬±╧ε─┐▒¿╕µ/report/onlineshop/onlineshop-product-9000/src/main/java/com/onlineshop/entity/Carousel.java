package com.onlineshop.entity;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * (Carousel)表实体类
 *
 * @author makejava
 * @since 2022-12-15 16:21:56
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("CAROUSEL")
public class Carousel  {
    @TableId
    @JsonProperty("carouse_id")
    private Integer carouselId;

    
    private String describes;
    
    private String imgPath;



}
