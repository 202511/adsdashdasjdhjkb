package com.onlineshop.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.onlineshop.entity.Category;

/**
 * (Category)表服务接口
 *
 * @author makejava
 * @since 2022-12-16 00:06:21
 */
public interface CategoryService extends IService<Category> {

}

