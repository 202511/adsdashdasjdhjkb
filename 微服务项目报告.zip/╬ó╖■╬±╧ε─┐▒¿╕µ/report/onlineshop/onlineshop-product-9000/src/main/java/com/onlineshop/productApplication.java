package com.onlineshop;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@MapperScan("com.onlineshop.mapper")
@SpringBootApplication
public class productApplication {
    public static void main(String[] args)
    {
        SpringApplication.run(productApplication.class,args);
    }
}
