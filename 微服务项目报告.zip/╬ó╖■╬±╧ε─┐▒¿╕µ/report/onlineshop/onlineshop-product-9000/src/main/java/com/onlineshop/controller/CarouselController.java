package com.onlineshop.controller;



import com.onlineshop.entity.CarouselDto;
import com.onlineshop.mapper.CarouselMapper;
import com.onlineshop.service.CarouselService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.List;

/**
 * (Carousel)表控制层
 *
 * @author makejava
 * @since 2022-12-15 10:12:51
 */
@RestController
@RequestMapping("/resources")
public class CarouselController {
    @Autowired
    private CarouselService carouselService;
    @PostMapping("/carousel")
    public CarouselDto getCarousels()
    {
        CarouselDto carouselDto=new CarouselDto(carouselService.carousel());
        return carouselDto;
    }


}

