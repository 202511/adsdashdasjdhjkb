package com.onlineshop.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.onlineshop.Dto.CategoryDto;
import com.onlineshop.Dto.ProductDto;
import com.onlineshop.Dto.ProductPictureDto;
import com.onlineshop.entity.Category;
import com.onlineshop.entity.Data;
import com.onlineshop.entity.Product;
import com.onlineshop.mapper.ProductMapper;
import com.onlineshop.service.CategoryService;
import com.onlineshop.service.ProductPictureService;
import com.onlineshop.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * (Product)表控制层
 *
 * @author makejava
 * @since 2022-12-08 15:29:50
 */
@RestController
@RequestMapping("/product")
public class ProductController {
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private ProductService productService;
    @Autowired
    private ProductPictureService productPictureService;
    @GetMapping("")
    public String a()
    {
        return "sadas";
    }
    @GetMapping("/h")
    public String as()
    {
        return "sadas";
    }
    @PostMapping("/getProduct")
    public Product getById(@RequestBody Integer id)
    {
        return productService.GetProductById(id);
    }
    @PostMapping("/getDetailsPicture" )
    public ProductPictureDto getDetailsPicture(@RequestBody JSONObject jsonObject)
    {
        return new ProductPictureDto("001",productPictureService.getDetailsPicture((Integer)jsonObject.get("productID")));
    }
    @PostMapping("/getAllProduct")
    public ProductDto getAllProduct(@RequestBody Data dates)
    {
        ProductDto productDto=new ProductDto(productService.GetAllProduct(dates.getCurrentPage(),dates.getPageSize()));
        return productDto;
    }
    @PostMapping("/getProuctById")
    public Product ById(@RequestBody Integer product_id)
    {
        List list =productService.GetDetails(product_id);
        if (list.size()>0)
        {
            return (Product) list.get(0);
        }
        return null;
    }
    @PostMapping("/getPromoProduct")
    public ProductDto getPromoProduct(@RequestBody JSONObject jsonObject)
    {
        if(((String)jsonObject.get("categoryName")).equals("推荐"))
        {
            return null;
        }
        QueryWrapper<Category>queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("category_name",(String)jsonObject.get("categoryName"));
        Category category=categoryService.getOne(queryWrapper);
        return productService.getPromoProduct(category.getCategoryId());
    }

    @PostMapping("/getCategory")
    public CategoryDto getCategory()
    {
        return new CategoryDto("001",categoryService.list(null));
    }
    @PostMapping("/getDetails")
    public ProductDto getDetails(@RequestBody JSONObject jsonObject)
    {
        ProductDto productDto=new ProductDto(productService.GetDetails((Integer)jsonObject.get("productID")));
        return productDto;
    }
    @PostMapping("/getProductByCategory")
    public ProductDto GetProductByCategory(@RequestBody Data data)
    {
        return new ProductDto(productService.GetProductByCategory(data.getCategoryID(),data.getCurrentPage(),data.getPageSize()));
    }
    @PostMapping("/getProductBySearch")
    public ProductDto getProductBySearch(@RequestBody JSONObject jsonObject)
    {
        return new ProductDto(productService.GetProductBySearch((Integer) jsonObject.get("currentPage"),(Integer) jsonObject.get("pageSize"),(String)jsonObject.get("search")));
    }

}

