package com.onlineshop.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CarouselDto {
    @JsonProperty("carousel")
    private List<Carousel>list;
    private String code;
    public CarouselDto(List<Carousel> list)
    {
        this.code="001";
        this.list=list;
    }
}
