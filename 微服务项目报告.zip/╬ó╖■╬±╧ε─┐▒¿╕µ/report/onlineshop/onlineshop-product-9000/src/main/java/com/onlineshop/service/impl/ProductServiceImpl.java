package com.onlineshop.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.onlineshop.Dto.ProductDto;
import com.onlineshop.entity.Product;
import com.onlineshop.mapper.ProductMapper;
import com.onlineshop.service.ProductService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * (Product)表服务实现类
 *
 * @author makejava
 * @since 2022-12-08 15:29:54
 */
@Service("productService")
public class ProductServiceImpl extends ServiceImpl<ProductMapper, Product> implements ProductService {

    @Override
    public ProductDto GetPromoProduct(Integer categoryID) {
        QueryWrapper<Product> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("category_id",categoryID);
        queryWrapper.orderByAsc("product_sales");
        queryWrapper.last("limit 7");
        ProductDto productDto=new ProductDto(list(queryWrapper));
        return productDto;
    }

    @Override
    public List GetDetails(Integer productID) {
        QueryWrapper<Product>queryWrapper=new QueryWrapper<>();
        queryWrapper.eq(" product_id",productID);

        return list(queryWrapper);
    }

    @Override
    public List GetAllProduct(Integer currentPage, Integer pageSize) {
        QueryWrapper<Product>queryWrapper=new QueryWrapper<>();
        Page<Product> page=new Page<>();
        page.setSize(pageSize);
        page.setCurrent(currentPage);
        page(page,queryWrapper);
        return page.getRecords();
    }

    @Override
    public List GetProductBySearch(Integer currentPage, Integer pageSize, String search) {
        QueryWrapper<Product>queryWrapper=new QueryWrapper<>();
        Page<Product>page=new Page<>();
        queryWrapper.like("product_name",search).or().like("product_intro",search);
        page.setCurrent(currentPage);
        page.setSize(pageSize);
        page(page,queryWrapper);
        return page.getRecords();
    }

    @Override
    public Product GetProductById(Integer id) {
        return  baseMapper.selectById(id);
    }

    @Override
    public List GetProductByCategory(List categoryId, Integer currentPage, Integer pageSize) {
        QueryWrapper<Product>queryWrapper=new QueryWrapper<>();
        for(Object i:categoryId)
        {
            queryWrapper.eq("category_id",(Integer)i);
        }
        Page<Product>page=new Page<>();
        page.setSize(pageSize);
        page.setCurrent(currentPage);
        page(page,queryWrapper);
        return page.getRecords();
    }

    @Override
    public Product get(Integer id) {
        return null;
    }

    @Override
    public ProductDto getPromoProduct(Integer categoryId) {
        QueryWrapper<Product>queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("CATEGORY_ID",categoryId);
        List<Product>list=list(queryWrapper);
        if (list.size()<=0) {
            return null;
        }
        return new ProductDto(list);
    }
}

