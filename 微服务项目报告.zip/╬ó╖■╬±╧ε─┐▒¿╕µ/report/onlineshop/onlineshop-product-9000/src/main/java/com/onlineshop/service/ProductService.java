package com.onlineshop.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.onlineshop.Dto.ProductDto;
import com.onlineshop.entity.Product;

import java.util.List;

/**
 * (Product)表服务接口
 *
 * @author makejava
 * @since 2022-12-08 15:29:53
 */
public interface ProductService extends IService<Product> {
    ProductDto GetPromoProduct(Integer categoryID);
    List GetDetails(Integer productID);
    List GetAllProduct(Integer currentPage,Integer pageSize);
    List GetProductBySearch(Integer currentPage,Integer pageSize,String search);
    Product GetProductById(Integer id);
    List GetProductByCategory(List categoryId,Integer currentPage,Integer pageSize);

    Product get(Integer id);

    ProductDto getPromoProduct(Integer categoryId);
}

