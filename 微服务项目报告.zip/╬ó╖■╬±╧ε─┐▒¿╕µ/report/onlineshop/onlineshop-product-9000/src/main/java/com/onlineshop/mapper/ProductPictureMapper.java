package com.onlineshop.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.onlineshop.entity.ProductPicture;


/**
 * (ProductPicture)表数据库访问层
 *
 * @author makejava
 * @since 2022-12-15 19:12:16
 */
public interface ProductPictureMapper extends BaseMapper<ProductPicture> {

}
