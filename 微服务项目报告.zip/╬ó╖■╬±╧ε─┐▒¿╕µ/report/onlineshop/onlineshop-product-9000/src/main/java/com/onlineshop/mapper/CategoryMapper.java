package com.onlineshop.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.onlineshop.entity.Category;


/**
 * (Category)表数据库访问层
 *
 * @author makejava
 * @since 2022-12-16 00:06:21
 */
public interface CategoryMapper extends BaseMapper<Category> {

}
