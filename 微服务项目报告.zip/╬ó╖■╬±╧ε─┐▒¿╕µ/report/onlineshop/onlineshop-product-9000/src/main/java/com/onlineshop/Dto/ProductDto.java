package com.onlineshop.Dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductDto<T> implements Serializable {
    private  String code;
    private  Integer total;
    @JsonProperty("Product")
    private T Product;
    public ProductDto(T Product)
    {
        this.code="001";
        this.Product=Product;
        this.total=((List)Product).size();
    }
    //public ProductDto()


}
