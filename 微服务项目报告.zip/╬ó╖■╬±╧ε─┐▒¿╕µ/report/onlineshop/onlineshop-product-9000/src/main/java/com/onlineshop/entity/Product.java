package com.onlineshop.entity;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * (Product)表实体类
 *
 * @author makejava
 * @since 2022-12-08 15:29:53
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("PRODUCT")
public class Product  {
    @TableId
    @JsonProperty("product_id")
    private Integer productId;

    @JsonProperty("product_name")
    private String productName;
    @JsonProperty("category_id")
    private Integer categoryId;
    @JsonProperty("product_title")
    private String productTitle;
    @JsonProperty("product_intro")
    private String productIntro;
    @JsonProperty("product_picture")
    private String productPicture;
    @JsonProperty("product_price")
    private Float productPrice;
    @JsonProperty("product_selling_price")
    private Float productSellingPrice;
    @JsonProperty("product_num")
    private Integer productNum;
    @JsonProperty("productSales")
    private Integer productSales;



}
