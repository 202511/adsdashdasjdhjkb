package com.onlineshop.entity;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.util.List;

@lombok.Data
@AllArgsConstructor
@NoArgsConstructor
public class Data {

    private Integer pageSize;
    private Integer currentPage;
    private List categoryID;
}
