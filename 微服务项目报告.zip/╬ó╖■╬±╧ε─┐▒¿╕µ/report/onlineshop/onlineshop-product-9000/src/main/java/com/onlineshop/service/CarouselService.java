package com.onlineshop.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.onlineshop.entity.Carousel;

import java.util.List;

/**
 * (Carousel)表服务接口
 *
 * @author makejava
 * @since 2022-12-15 10:12:52
 */
public interface CarouselService extends IService<Carousel> {
    List<Carousel> carousel();
}

