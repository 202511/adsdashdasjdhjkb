package com.onlineshop.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.onlineshop.entity.Carousel;


/**
 * (Carousel)表数据库访问层
 *
 * @author makejava
 * @since 2022-12-15 10:12:52
 */
public interface CarouselMapper extends BaseMapper<Carousel> {

}
