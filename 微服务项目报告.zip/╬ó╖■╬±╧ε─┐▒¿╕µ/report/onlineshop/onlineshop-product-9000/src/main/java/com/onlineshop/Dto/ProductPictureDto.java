package com.onlineshop.Dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.onlineshop.entity.ProductPicture;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class ProductPictureDto {
    private String code;
    @JsonProperty("ProductPicture")
    private List<ProductPicture>productPictures;

}
