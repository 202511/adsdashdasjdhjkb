package com.onlineshop.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.onlineshop.entity.ProductPicture;
import com.onlineshop.mapper.ProductPictureMapper;
import com.onlineshop.service.ProductPictureService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * (ProductPicture)表服务实现类
 *
 * @author makejava
 * @since 2022-12-15 19:12:16
 */
@Service("productPictureService")
public class ProductPictureServiceImpl extends ServiceImpl<ProductPictureMapper, ProductPicture> implements ProductPictureService {

    @Override
    public List<ProductPicture> getDetailsPicture(Integer productId) {
        QueryWrapper<ProductPicture>queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("PRODUCT_ID",productId);
        return list(queryWrapper);

    }
}

