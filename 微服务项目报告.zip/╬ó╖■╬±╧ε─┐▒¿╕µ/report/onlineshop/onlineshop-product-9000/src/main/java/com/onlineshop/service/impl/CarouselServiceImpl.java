package com.onlineshop.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.onlineshop.entity.Carousel;
import com.onlineshop.mapper.CarouselMapper;
import com.onlineshop.service.CarouselService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * (Carousel)表服务实现类
 *
 * @author makejava
 * @since 2022-12-15 10:12:52
 */
@Service("carouselService")
public class CarouselServiceImpl extends ServiceImpl<CarouselMapper, Carousel> implements CarouselService {

    @Override
    public List<Carousel> carousel() {

        return baseMapper.selectList(null);
    }
}

