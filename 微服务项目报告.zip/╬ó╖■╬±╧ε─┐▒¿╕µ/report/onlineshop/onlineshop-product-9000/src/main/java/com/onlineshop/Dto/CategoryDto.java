package com.onlineshop.Dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.onlineshop.entity.Category;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CategoryDto {
    private String code;
    @JsonProperty("category")
    private List<Category>categoryDtoList;
}
