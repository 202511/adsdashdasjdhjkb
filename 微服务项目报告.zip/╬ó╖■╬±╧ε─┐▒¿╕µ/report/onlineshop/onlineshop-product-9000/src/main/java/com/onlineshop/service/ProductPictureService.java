package com.onlineshop.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.onlineshop.entity.ProductPicture;

import java.util.List;

/**
 * (ProductPicture)表服务接口
 *
 * @author makejava
 * @since 2022-12-15 19:12:16
 */
public interface ProductPictureService extends IService<ProductPicture> {

    List<ProductPicture> getDetailsPicture(Integer productId);
}

