package com.onlineshop.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.onlineshop.entity.Product;


/**
 * (Product)表数据库访问层
 *
 * @author makejava
 * @since 2022-12-08 15:29:52
 */
public interface ProductMapper extends BaseMapper<Product> {

}
