package com.gateWay.comfig;

public class RouteLocator {
}
