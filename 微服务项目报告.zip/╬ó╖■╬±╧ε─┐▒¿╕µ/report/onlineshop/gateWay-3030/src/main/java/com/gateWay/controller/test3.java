package com.gateWay.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping()
@RestController
public class test3 {
    @RequestMapping("")
    public String tesy()
    {
        return "dsasdada";
    }

}
