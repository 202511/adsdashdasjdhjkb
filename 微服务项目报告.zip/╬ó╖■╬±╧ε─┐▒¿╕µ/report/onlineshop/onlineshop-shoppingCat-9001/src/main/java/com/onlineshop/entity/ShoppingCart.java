package com.onlineshop.entity;


import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * (ShoppingCart)表实体类
 *
 * @author makejava
 * @since 2022-12-08 15:47:27
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("SHOPPING_CART")
public class ShoppingCart  {
    @TableId
    private Integer id;

    
    private Integer userId;
    
    private Integer productId;
    
    private Integer num;
    public  ShoppingCart(Integer userId,Integer productId,Integer num)
    {
        this.userId=userId;
        this.productId=productId;
        this.num=num;
    }



}
