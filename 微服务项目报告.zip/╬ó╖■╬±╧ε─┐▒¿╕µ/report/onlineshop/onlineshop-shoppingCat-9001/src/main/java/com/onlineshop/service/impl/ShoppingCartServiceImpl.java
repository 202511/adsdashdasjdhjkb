package com.onlineshop.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.onlineshop.Dto.ResponseResult;
import com.onlineshop.entity.ShoppingCart;
import com.onlineshop.mapper.ShoppingCartMapper;
import com.onlineshop.service.ShoppingCartService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * (ShoppingCart)表服务实现类
 *
 * @author makejava
 * @since 2022-12-08 15:47:28
 */
@Service("shoppingCartService")
public class ShoppingCartServiceImpl extends ServiceImpl<ShoppingCartMapper, ShoppingCart> implements ShoppingCartService {
    @Override
    public List GetShoppingCart(Integer user_id) {
        QueryWrapper<ShoppingCart> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("user_id",user_id);
        return list(queryWrapper);
    }

    @Override
    public ShoppingCart FindShoppingCart(Integer user_id, Integer product_id) {
        QueryWrapper<ShoppingCart>queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("user_id",user_id);
        queryWrapper.eq("product_id",product_id);
        return list(queryWrapper).get(0);
    }

    @Override
    public ShoppingCart AddShoppingCart(Integer user_id, Integer product_id) {
        ShoppingCart shoppingcart=new ShoppingCart(user_id,product_id,1);
        save(shoppingcart);
        return shoppingcart;
    }

    @Override
    public ResponseResult UpdateShoppingCart(Integer NewNum, Integer user_id, Integer product_id) {
        UpdateWrapper<ShoppingCart> updateWrapper=new UpdateWrapper<>();
        updateWrapper.eq("user_id",user_id);
        updateWrapper.eq("product_id",product_id);
        updateWrapper.set("num",NewNum);
        baseMapper.update(null,updateWrapper);
        return new ResponseResult("001","修改购物车数量成功");
    }

    @Override
    public ResponseResult DeleteShoppingCart(Integer user_id, Integer product_id) {
        QueryWrapper<ShoppingCart>queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("user_id",user_id);
        queryWrapper.eq("product_id",product_id);
        baseMapper.delete(queryWrapper);
        return new ResponseResult("001","删除购物车成功");
    }

    @Override
    public List<ShoppingCart> getShoppingCart(Integer user_id) {
        QueryWrapper<ShoppingCart>queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("user_id",user_id);
        return list(queryWrapper);
    }
}

