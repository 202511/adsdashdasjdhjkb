package com.onlineshop.Dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ShoppingCartDto {
    String code;
    String msg;
    @JsonProperty("shoppingCartData")
    List<ShoppingCartData> shoppingCartData;

}