package com.onlineshop.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.onlineshop.Dto.ResponseResult;
import com.onlineshop.entity.ShoppingCart;

import java.util.List;

/**
 * (ShoppingCart)表服务接口
 *
 * @author makejava
 * @since 2022-12-08 15:47:27
 */
public interface ShoppingCartService extends IService<ShoppingCart> {
    List GetShoppingCart(Integer user_id);
    ShoppingCart FindShoppingCart(Integer user_id,Integer product_id);
    ShoppingCart AddShoppingCart(Integer user_id,Integer product_id);
    ResponseResult UpdateShoppingCart(Integer NewNum, Integer user_id, Integer product_id);
    ResponseResult DeleteShoppingCart(Integer user_id,Integer product_id);

    List<ShoppingCart> getShoppingCart(Integer user_id);
}

