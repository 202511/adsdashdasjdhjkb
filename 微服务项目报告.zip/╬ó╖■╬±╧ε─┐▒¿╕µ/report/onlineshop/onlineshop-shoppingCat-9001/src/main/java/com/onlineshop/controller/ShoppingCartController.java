package com.onlineshop.controller;



import com.alibaba.fastjson.JSONObject;
import com.onlineshop.Dto.ResponseResult;
import com.onlineshop.Dto.ShoppingCartData;
import com.onlineshop.Dto.ShoppingCartDto;
import com.onlineshop.Feign.ProductService;
import com.onlineshop.entity.Product;
import com.onlineshop.entity.ShoppingCart;
import com.onlineshop.service.ShoppingCartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * (ShoppingCart)表控制层
 *
 * @author makejava
 * @since 2022-12-08 15:47:25
 */
@RestController
@RequestMapping("/user/shoppingCart")
public class ShoppingCartController {
    @Autowired
    private ProductService productService;
    @Autowired
    private ShoppingCartService shoppingcartService;
    @GetMapping("")
    public String sd()
    {
        return "sdad";
    }
    @GetMapping("/s")
    public String swd()
    {
        return "sdad";
    }
    @PostMapping("/updateShoppingCart")
    public ResponseResult updateShoppingCart(@RequestBody JSONObject jsonObject)
    {
        return shoppingcartService.UpdateShoppingCart((Integer) jsonObject.get("num"),(Integer) jsonObject.get("user_id"),(Integer)jsonObject.get("product_id"));
    }
    @PostMapping("/deleteShoppingCart")
    public ResponseResult deleteShoppingCart(@RequestBody JSONObject jsonObject)
    {
        return shoppingcartService.DeleteShoppingCart((Integer) jsonObject.get("user_id"),(Integer)jsonObject.get("product_id"));
    }
    @PostMapping("/getShoppingCart")
    public ShoppingCartDto getShoppingCart(@RequestBody JSONObject jsonObject)
    {
        List<ShoppingCart>shoppingCartList=shoppingcartService.getShoppingCart((Integer)jsonObject.get("user_id"));
        List<ShoppingCartData> list=new ArrayList<>();
        for (ShoppingCart i : shoppingCartList) {

            Product product=productService.GetDetails(i.getProductId());
            ShoppingCartData shoppingCartData=new ShoppingCartData();
            shoppingCartData.setNum(i.getNum());
            shoppingCartData.setId(i.getId());
            shoppingCartData.setProductID(i.getProductId());
            shoppingCartData.setMaxNum(10);
            if (product==null){continue;}
            shoppingCartData.setProductName(product.getProductName());
            shoppingCartData.setPrice(product.getProductPrice());
            shoppingCartData.setProductImg(product.getProductPicture());
            list.add(shoppingCartData);
        }
        ShoppingCartDto shoppingCartDto=new ShoppingCartDto();
        shoppingCartDto.setCode("001");
        shoppingCartDto.setShoppingCartData(list);
        return shoppingCartDto;
    }
    @PostMapping("/addShoppingCart")
    public ShoppingCartDto addShoppingCart(@RequestBody JSONObject jsonObject)
    {
        ShoppingCartData shoppingCartData=new ShoppingCartData();
        ShoppingCartDto shoppingCartDto=new ShoppingCartDto();
        ShoppingCart shoppingcart=shoppingcartService.AddShoppingCart((Integer) jsonObject.get("user_id"),(Integer) jsonObject.get("product_id"));
        Product product=productService.GetDetails((Integer) jsonObject.get("product_id"));
        shoppingCartDto.setCode("001");
        shoppingCartDto.setMsg("添加购物车成功");
        shoppingCartData.setNum(shoppingcart.getNum());
        shoppingCartData.setId(shoppingcart.getId());
        shoppingCartData.setProductID(shoppingcart.getProductId());
        shoppingCartData.setMaxNum(10);
        shoppingCartData.setProductName(product.getProductName());
        shoppingCartData.setPrice(product.getProductPrice());
        List<ShoppingCartData> list=new ArrayList<>();
        list.add(shoppingCartData);
        shoppingCartDto.setShoppingCartData(list);
        return shoppingCartDto;
    }

}

