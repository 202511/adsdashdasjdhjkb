package com.onlineshop.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.onlineshop.entity.ShoppingCart;


/**
 * (ShoppingCart)表数据库访问层
 *
 * @author makejava
 * @since 2022-12-08 15:47:26
 */
public interface ShoppingCartMapper extends BaseMapper<ShoppingCart> {

}
