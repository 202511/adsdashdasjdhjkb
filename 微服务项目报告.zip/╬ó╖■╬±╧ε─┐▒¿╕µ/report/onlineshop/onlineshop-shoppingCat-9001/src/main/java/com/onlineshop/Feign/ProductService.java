package com.onlineshop.Feign;

import com.alibaba.fastjson.JSONObject;
import com.onlineshop.entity.Product;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@FeignClient(name = "onlineshop-product",path = "/product")
public interface ProductService {
    @PostMapping("/getProuctById")
    Product GetDetails(@RequestBody Integer product_id);
}
