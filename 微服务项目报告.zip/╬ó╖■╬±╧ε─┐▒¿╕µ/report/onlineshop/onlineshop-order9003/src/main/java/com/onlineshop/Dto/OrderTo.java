package com.onlineshop.Dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
@AllArgsConstructor
@Data
@NoArgsConstructor
public class OrderTo {
    private Integer id;
    @JsonProperty("product_name")
    private String product_name;
    @JsonProperty("product_picture")
    private String product_picture;
    @JsonProperty("order_id")
    private String orderId;
    @JsonProperty("user_id")
    private Integer userId;
    @JsonProperty("product_id")
    private Integer productId;
    @JsonProperty("product_num")
    private Integer productNum;
    @JsonProperty("product_price")
    private Float productPrice;
    @JsonProperty("order_time")
    private Date orderTime;
}
