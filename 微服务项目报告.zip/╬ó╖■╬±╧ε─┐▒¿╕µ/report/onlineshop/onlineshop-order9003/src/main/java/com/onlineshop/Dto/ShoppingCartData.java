package com.onlineshop.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ShoppingCartData {
    Integer id;
    Integer productID;
    String productName;
    String productImg;
    Integer maxNum;
    Integer num;
    Float price;
    Boolean check;
}