package com.onlineshop.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.onlineshop.Dto.ResponseResult;
import com.onlineshop.Dto.ShoppingCartData;
import com.onlineshop.entity.Orders;

import java.util.List;

/**
 * (Orders)表服务接口
 *
 * @author makejava
 * @since 2022-12-08 22:10:34
 */
public interface OrdersService extends IService<Orders> {
    // 连接数据库获取所有的订单id
    List GetOrderGroup(Integer user_id);
    // 连接数据库获取所有的订单详细信息,订单时间
    List GetOrder(Integer user_id);
    // 连接数据库插入订单信息
    ResponseResult AddOrder(Integer user_id, ShoppingCartData shoppingCartData);
}

