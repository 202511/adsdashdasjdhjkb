package com.onlineshop.entity;

public class Ordto {
}
