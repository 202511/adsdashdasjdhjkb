package com.onlineshop.controller;

import com.onlineshop.Dto.*;
import com.onlineshop.Feign.ProductService;
import com.onlineshop.entity.Orders;
import com.onlineshop.entity.Product;
import com.onlineshop.service.OrdersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * (Orders)表控制层
 *
 * @author makejava
 * @since 2022-12-08 22:10:32
 */
@RestController
@RequestMapping("/user/order")
public class OrdersController {
    @Autowired
    private OrdersService ordersService;
    @Autowired
    private ProductService productService;
    @PostMapping("/addOrder")
    public ResponseResult addOrder(@RequestBody OrderDto orderDto)
    {
        return ordersService.AddOrder(orderDto.getUser_id(), (ShoppingCartData) orderDto.getProducts().get(0));
    }
    @PostMapping("/getOrder")
    public Response getOrder()
    {
        List<List<OrderTo>>list=new ArrayList<>();
        List<Orders>orderList=ordersService.list(null);

        for(int i=0;i<orderList.size();i++)
        {
            List<OrderTo>listTmp=new ArrayList<>();
            Product product=productService.getById(orderList.get(i).getProductId());
            OrderTo orderTo=new OrderTo();
            orderTo.setId(orderList.get(i).getId());
            orderTo.setOrderId(orderList.get(i).getOrderId());
            orderTo.setOrderTime(orderList.get(i).getOrderTime());
            orderTo.setProductId(orderList.get(i).getProductId());
            orderTo.setProduct_name(product.getProductName());
            orderTo.setProductNum(orderList.get(i).getProductNum());
            orderTo.setProduct_picture(product.getProductPicture());
            orderTo.setProductPrice(product.getProductPrice());
            orderTo.setUserId(orderList.get(i).getUserId());
            listTmp.add(orderTo);
            list.add(listTmp);
        }
        return new Response("001",list);
    }

}

