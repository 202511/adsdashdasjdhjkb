package com.onlineshop.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.onlineshop.entity.Orders;


/**
 * (Orders)表数据库访问层
 *
 * @author makejava
 * @since 2022-12-08 22:10:33
 */
public interface OrdersMapper extends BaseMapper<Orders> {

}
