package com.onlineshop.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.onlineshop.Dto.ResponseResult;
import com.onlineshop.Dto.ShoppingCartData;
import com.onlineshop.entity.Orders;
import com.onlineshop.mapper.OrdersMapper;
import com.onlineshop.service.OrdersService;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * (Orders)表服务实现类
 *
 * @author makejava
 * @since 2022-12-08 22:10:35
 */
@Service("ordersService")
public class OrdersServiceImpl extends ServiceImpl<OrdersMapper, Orders> implements OrdersService {
    @Override
    public List GetOrderGroup(Integer user_id) {
        QueryWrapper<Orders> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("user_id",user_id);
        queryWrapper.orderByAsc("productId");
        return list(queryWrapper);
    }

    @Override
    public  List GetOrder(Integer user_id) {
        QueryWrapper<Orders>queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("user_id",user_id);
        return list(queryWrapper);
    }

    @Override
    public ResponseResult AddOrder(Integer user_id, ShoppingCartData shoppingCartData) {
        Orders orders=new Orders();
        Date currenDate=new Date();
        orders.setOrderId(user_id.toString()+new Date().toString());
        orders.setUserId(user_id);
        orders.setProductId(shoppingCartData.getProductID());
        orders.setProductPrice(shoppingCartData.getPrice());
        orders.setProductNum(shoppingCartData.getNum());
        orders.setOrderTime(new Date());
        save(orders);
        return new ResponseResult("001","购买成功");
    }
}

