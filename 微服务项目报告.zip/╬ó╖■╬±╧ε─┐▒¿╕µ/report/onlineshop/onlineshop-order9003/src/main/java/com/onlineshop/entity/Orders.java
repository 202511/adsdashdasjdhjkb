package com.onlineshop.entity;

import java.util.Date;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * (Orders)表实体类
 *
 * @author makejava
 * @since 2022-12-08 22:10:34
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("ORDERS")
public class Orders  {
    @TableId
    private Integer id;

    
    private String orderId;
    
    private Integer userId;
    
    private Integer productId;
    
    private Integer productNum;
    
    private Float productPrice;
    
    private Date orderTime;



}
