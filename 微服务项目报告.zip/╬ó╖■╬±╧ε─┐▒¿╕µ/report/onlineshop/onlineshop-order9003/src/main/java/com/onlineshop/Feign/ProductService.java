package com.onlineshop.Feign;

import com.onlineshop.entity.Product;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "onlineshop-product",path = "/product")
public interface ProductService {
    @PostMapping("/getProduct")
    Product getById(@RequestBody Integer id);
}
