package com.onlineshop.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderDto <T> implements Serializable {
    private Integer user_id;
    private List<ShoppingCartData>products=new ArrayList<>();
}
