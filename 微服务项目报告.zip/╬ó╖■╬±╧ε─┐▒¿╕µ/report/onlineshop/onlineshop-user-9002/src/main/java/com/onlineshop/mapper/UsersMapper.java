package com.onlineshop.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.onlineshop.entity.Users;


/**
 * (Users)表数据库访问层
 *
 * @author makejava
 * @since 2022-12-12 19:37:46
 */
public interface UsersMapper extends BaseMapper<Users> {

}
