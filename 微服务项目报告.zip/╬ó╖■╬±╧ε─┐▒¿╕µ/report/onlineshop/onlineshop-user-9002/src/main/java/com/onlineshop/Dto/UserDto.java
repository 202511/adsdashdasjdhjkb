package com.onlineshop.Dto;

import com.onlineshop.entity.Users;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {
    private String code;
    private String msg;
    private Users user;
    public UserDto(Users user)
    {
        this.code="001";
        this.msg="登录成功";
        this.user=user;
    }

}
