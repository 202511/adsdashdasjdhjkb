package com.onlineshop.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.onlineshop.Dto.ResponseResult;
import com.onlineshop.entity.Users;
import com.onlineshop.mapper.UsersMapper;
import com.onlineshop.service.UsersService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * (Users)表服务实现类
 *
 * @author makejava
 * @since 2022-12-12 19:37:48
 */
@Service("usersService")
public class UsersServiceImpl extends ServiceImpl<UsersMapper, Users> implements UsersService {
    @Override
    public ResponseResult Register(String userName, String password) {
        Users users=new Users();
        users.setUserName(userName);
        users.setPassword(password);
        save(users);
        return new ResponseResult("001","注册成功");
    }

    @Override
    public ResponseResult FindUserName(String userName) {
        QueryWrapper<Users> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("user_name",userName);
        if (list(queryWrapper).size()!=0)
        {
            return new ResponseResult("004","用户名已经存在，不能注册");
        }
        return new ResponseResult("001","用户名不存在，可以注册");
    }

    @Override
    public Users Login(String userName, String password) {
        QueryWrapper<Users>queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("user_name",userName);
        queryWrapper.eq("password",password);
        List<Users> list=list(queryWrapper);
        if (list==null){return null;}
        Users users=list.get(0);
        System.out.println(users);
        return users;
    }

}

