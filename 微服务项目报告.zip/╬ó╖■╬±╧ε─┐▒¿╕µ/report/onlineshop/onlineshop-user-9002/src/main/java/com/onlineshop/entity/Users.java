package com.onlineshop.entity;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * (Users)表实体类
 *
 * @author makejava
 * @since 2022-12-15 12:41:56
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("USERS")
public class Users  {
    @TableId
    @JsonProperty("user_id")
    private Integer userId;

    
    private String password;
    
    private String userPhoneNumber;
    @JsonProperty("userName")
    private String userName;



}
