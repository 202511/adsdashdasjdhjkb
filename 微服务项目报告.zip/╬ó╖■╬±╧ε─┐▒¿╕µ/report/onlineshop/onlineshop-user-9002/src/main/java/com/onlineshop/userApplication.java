package com.onlineshop;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.onlineshop.mapper")
public class userApplication {
    public static void main(String[] args)
    {
        SpringApplication.run(userApplication.class,args);
    }
}
