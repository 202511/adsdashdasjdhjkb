package com.onlineshop.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.onlineshop.Dto.ResponseResult;
import com.onlineshop.entity.Users;

/**
 * (Users)表服务接口
 *
 * @author makejava
 * @since 2022-12-12 19:37:47
 */
public interface UsersService extends IService<Users> {
    ResponseResult Register(String userName, String password);
    ResponseResult FindUserName(String userName);
    Users Login(String userName,String password);
}

