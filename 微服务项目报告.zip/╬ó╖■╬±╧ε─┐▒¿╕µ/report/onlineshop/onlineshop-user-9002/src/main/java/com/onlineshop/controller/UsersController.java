package com.onlineshop.controller;


import com.alibaba.fastjson.JSONObject;
import com.onlineshop.Dto.ResponseResult;
import com.onlineshop.Dto.UserDto;
import com.onlineshop.service.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * (Users)表控制层
 *
 * @author makejava
 * @since 2022-12-12 19:37:45
 */
@RestController
@RequestMapping("/users")
public class UsersController {
    @Autowired
    private UsersService usersService;
    @GetMapping("")
    public String sd()
    {
        return "sda";
    }
    @GetMapping("/h")
    public String d()
    {
        return "sda";
    }
    @PostMapping("/findUserName")
    public ResponseResult findUserName(@RequestBody JSONObject jsonObject)
    {
        return usersService.FindUserName(jsonObject.getString("userName"));
    }
    @PostMapping("/register")
    public ResponseResult register(@RequestBody JSONObject jsonObject)
    {
        return usersService.Register(jsonObject.getString("userName"), jsonObject.getString("password"));
    }
    @PostMapping("/login")
    public UserDto login(@RequestBody JSONObject jsonObject)
    {
        return new UserDto(usersService.Login(jsonObject.getString("userName"), jsonObject.getString("password")));
    }
}
