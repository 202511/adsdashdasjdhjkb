
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
path = '电信客户数据.csv'
data= pd.read_csv(path)
# 去掉用户的id这一特征
customerID=data['customerID']
data.drop(['customerID'],axis=1, inplace=True)

cateCols = [c for c in data.columns if data[c].dtype == 'object' or c == 'SeniorCitizen']
dfCate = data[cateCols].copy()
# print(dfCate.head(3))
for col in cateCols:
    if dfCate[col].nunique() == 2:
        dfCate[col] = pd.factorize(dfCate[col])[0]
    else:
        dfCate = pd.get_dummies(dfCate, columns=[col])
dfCate['tenure']=data[['tenure']]
dfCate['MonthlyCharges']=data[['MonthlyCharges']]
dfCate['TotalCharges']=data[['TotalCharges']]
# 查看关联关系
plt.figure(figsize=(16,8))
dfCate.corr()['Churn'].sort_values(ascending=False).plot(kind='bar')
plt.show()

dropFea = ['gender','PhoneService',
           'OnlineSecurity_No internet service', 'OnlineBackup_No internet service',
           'DeviceProtection_No internet service', 'TechSupport_No internet service',
           'StreamingTV_No internet service', 'StreamingMovies_No internet service',
           ]
dfCate.drop(dropFea, inplace=True, axis =1) 
# #最后一列是作为标识
target = dfCate['Churn'].values
#列表：特征和1个标识
columns = dfCate.columns.tolist()
print(columns)
dfCate.to_csv("清洗后的数据.csv")