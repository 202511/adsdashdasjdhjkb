
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
path = '清洗后的数据.csv'
dfCate= pd.read_csv(path)
target = dfCate['Churn'].values
#列表：特征和1个标识
columns = dfCate.columns.tolist()
columns.remove('Churn')
# 含有特征的DataFrame
features = dfCate[columns].values
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.tree import export_graphviz
# 30% 作为测试集，其余作为训练集
# random_state = 1表示重复试验随机得到的数据集始终不变
# stratify = target 表示按标识的类别，作为训练数据集、测试数据集内部的分配比例
train_x, test_x, train_y, test_y = train_test_split(features, target, test_size=0.30, stratify = target, random_state = 11)
tree=DecisionTreeClassifier()
tree.fit(train_x,train_y)

# #特征重要性可视化
# import matplotlib.pyplot as plt
# def plot_feature_importance(model):
#     n_features = dfCate.shape[1]
#     plt.barh(range(n_features-1),model.feature_importances_,align='center')
#     plt.yticks(range(n_features-1),dfCate.columns[1:])
#     plt.xlabel('Features importance')
#     plt.ylabel('feature')
# plot_feature_importance(tree)
# plt.show()

# from sklearn import neighbors
# knn = neighbors.KNeighborsClassifier()
# knn.fit(train_x,train_y)

# predict_y_t=tree.predict(test_x)
# print(" 决策树模型的准确率 %0.4lf" %accuracy_score(test_y, predict_y_t))
# predict_y_k=knn.predict(test_x)
# print(" K近邻模型的准确率 %0.4lf" %accuracy_score(test_y, predict_y_k))
#决策树可视化
from sklearn.tree import export_graphviz

import pydot
import graphviz
from six import StringIO
dot_data=StringIO()
export_graphviz(tree,out_file=dot_data,class_names=['Churn_no','Churn_yes'],feature_names=dfCate.columns[1:],filled=True, rounded=True,special_characters=True)
#with open("te_tree.dot") as f:
#    dot_graph=f.read()
graph=pydot.graph_from_dot_data(dot_data.getvalue())
graph[0].write_pdf("tree.pdf")




# from sklearn.metrics import roc_curve #导入ROC曲线函数
# import matplotlib.pyplot as plt


# from sklearn.metrics import auc
# fpr, tpr, threshold = roc_curve(test_y,  tree.predict(test_x))
# roc_auc = auc(fpr,tpr)   # 准确率代表所有正确的占所有数据的比值
# print('tree roc_auc:', roc_auc)
# lw = 2
# plt.subplot(1,1,1)
# plt.plot(fpr, tpr, color='darkorange',
#          lw=lw, label='ROC curve (area = %0.2f)' % roc_auc)  # 假正率为横坐标，真正率为纵坐标做曲线
# fpr1, tpr1, threshold1 = roc_curve(test_y,  knn.predict(test_x))
# roc_auc1 = auc(fpr1,tpr1)   # 准确率代表所有正确的占所有数据的比值
# print('knn roc_auc:', roc_auc1)
# lw = 2
# plt.subplot(1,1,1)
# plt.plot(fpr1, tpr1, color='blue',
#          lw=lw, label='ROC curve (area = %0.2f)' % roc_auc1)  # 假正率为横坐标，真正率为纵坐标做曲线
# plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
# plt.xlim([0.0, 1.0])
# plt.ylim([0.0, 1.0])
# plt.xlabel('1 - specificity')
# plt.ylabel('Sensitivity')
# plt.title('ROC', y=0.5)
# plt.legend(loc="lower right")
# plt.show()

# from sklearn.metrics import confusion_matrix
# cm = confusion_matrix(test_y, knn.predict(test_x)) #混淆矩阵
# import matplotlib.pyplot as plt #导入作图库
# plt.matshow(cm, cmap=plt.cm.Greens) #画混淆矩阵图，配色风格使用cm.Greens，更多风格请参考官网。
# plt.colorbar() #颜色标签
# for x in range(len(cm)): #数据标签
#   for y in range(len(cm)):
#     plt.annotate(cm[x,y], xy=(x, y), horizontalalignment='center', verticalalignment='center')
# plt.ylabel('True label') #坐标轴标签
# plt.xlabel('Predicted label') #坐标轴标签
# plt.show() #显示作图结果
# cm1 = confusion_matrix(test_y, tree.predict(test_x)) #混淆矩阵
# plt.matshow(cm1, cmap=plt.cm.Greens) #画混淆矩阵图，配色风格使用cm.Greens，更多风格请参考官网。
# plt.colorbar() #颜色标签
# for x in range(len(cm1)): #数据标签
#   for y in range(len(cm1)):
#     plt.annotate(cm1[x,y], xy=(x, y), horizontalalignment='center', verticalalignment='center')
# plt.ylabel('True label') #坐标轴标签
# plt.xlabel('Predicted label') #坐标轴标签
# plt.show() #显示作图结果