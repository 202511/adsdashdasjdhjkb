import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
path = '电信客户数据.csv'
data= pd.read_csv(path)
# print('数据集的有多少行和多少列:')
# print(data.shape)
# # 是否又缺失值
# print('用户数据中的缺失值数量：')
# print(data.isnull().sum())
# # 数据类型
# print('各方面的用户信息：')
# print(data.dtypes)
print(data.describe())


# print(data.loc[:,'MonthlyCharges'])
# data.loc[:,'tenure'][data['tenure']==0]=1
# data.loc[:,'TotalCharges'][data['tenure']==0]=data.loc[:,'MonthlyCharges'][data['tenure']==0]
# data.to_csv("电信客户数据.csv")

# plt.rcParams['figure.figsize']=6,6
# plt.pie(data['Churn'].value_counts(),labels=data['Churn'].value_counts().index,autopct='%1.2f%%',explode=(0.1,0))
# plt.title('Churn(Yes/No) Ratio')
# plt.show()


# churnDf=data['Churn'].value_counts().to_frame()
# x=churnDf.index
# y=churnDf['Churn']
# plt.bar(x,y,width = 0.5,color = 'c')
# #用来正常显示中文标签（需要安装字库）
# plt.title('Churn(Yes/No) Num')
# plt.show()
# def barplot_percentages(feature,orient='v',axis_name="percentage of customers"):
#     ratios = pd.DataFrame()
#     g = (data.groupby(feature)["Churn"].value_counts()/len(data)).to_frame()
#     g.rename(columns={"Churn":axis_name},inplace=True)
#     g.reset_index(inplace=True)

#     #print(g)
#     if orient == 'v':
#         ax = sns.barplot(x=feature, y= axis_name, hue='Churn', data=g, orient=orient)
#         ax.set_yticklabels(['{:,.0%}'.format(y) for y in ax.get_yticks()])
#         plt.rcParams.update({'font.size': 9})
#         #plt.legend(fontsize=10)
#     else:
#         ax = sns.barplot(x= axis_name, y=feature, hue='Churn', data=g, orient=orient)
#         ax.set_xticklabels(['{:,.0%}'.format(x) for x in ax.get_xticks()])
#         plt.legend(fontsize=10)
#     plt.title('Churn(Yes/No) Ratio as {0}'.format(feature))
#     plt.show()
# barplot_percentages("SeniorCitizen")
# barplot_percentages("gender")
# data['churn_rate'] = data['Churn'].replace("No", 0).replace("Yes", 1)
# g = sns.FacetGrid(data, col="SeniorCitizen", height=4, aspect=.9)
# ax = g.map(sns.barplot, "gender", "churn_rate", palette = "Blues_d", order= ['Female', 'Male'])
# plt.rcParams.update({'font.size': 13})
# plt.show()
# fig, axis = plt.subplots(1, 2, figsize=(12,4))
# axis[0].set_title("Has Partner")
# axis[1].set_title("Has Dependents")
# axis_y = "percentage of customers"

# # Plot Partner column
# gp_partner = (data.groupby('Partner')["Churn"].value_counts()/len(data)).to_frame()
# gp_partner.rename(columns={"Churn": axis_y}, inplace=True)
# gp_partner.reset_index(inplace=True)
# ax1 = sns.barplot(x='Partner', y= axis_y, hue='Churn', data=gp_partner, ax=axis[0])
# ax1.legend(fontsize=10)
# #ax1.set_xlabel('伴侣')


# # Plot Dependents column
# gp_dep = (data.groupby('Dependents')["Churn"].value_counts()/len(data)).to_frame()
# #print(gp_dep)
# gp_dep.rename(columns={"Churn": axis_y} , inplace=True)
# #print(gp_dep)
# gp_dep.reset_index(inplace=True)
# #print(gp_dep)

# ax2 = sns.barplot(x='Dependents', y= axis_y, hue='Churn', data=gp_dep, ax=axis[1])
# #ax2.set_xlabel('家属')


# #设置字体大小
# plt.rcParams.update({'font.size': 20})
# ax2.legend(fontsize=10)

# #设置
# plt.show()
# Kernel density estimaton核密度估计
# def kdeplot(feature,xlabel):
#     plt.figure(figsize=(9, 4))
#     plt.title("KDE for {0}".format(feature))
#     ax0 = sns.kdeplot(data[data['Churn'] == 'No'][feature].dropna(), color= 'navy', label= 'Churn: No', shade='True')
#     ax1 = sns.kdeplot(data[data['Churn'] == 'Yes'][feature].dropna(), color= 'orange', label= 'Churn: Yes',shade='True')
#     plt.xlabel(xlabel)
#     #设置字体大小
#     plt.rcParams.update({'font.size': 20})
#     plt.legend(fontsize=10)
# kdeplot('tenure','tenure')
# plt.show()
# plt.figure(figsize=(9, 4.5))
# barplot_percentages("MultipleLines", orient='h')
# plt.figure(figsize=(9, 4.5))
# barplot_percentages("InternetService", orient="h")
# cols = ["PhoneService","MultipleLines","OnlineSecurity", "OnlineBackup", "DeviceProtection", "TechSupport", "StreamingTV", "StreamingMovies"]
# df1 = pd.melt(data[data["InternetService"] != "No"][cols])
# df1.rename(columns={'value': 'Has service'},inplace=True)
# plt.figure(figsize=(20, 8))
# ax = sns.countplot(data=df1, x='variable', hue='Has service')
# ax.set(xlabel='Internet Additional service', ylabel='Num of customers')
# plt.rcParams.update({'font.size':20})
# plt.legend( labels = ['No Service', 'Has Service'],fontsize=15)
# plt.title('Num of Customers as Internet Additional Service')
# plt.show()
# plt.figure(figsize=(20, 8))
# df1 = data[(data.InternetService != "No") & (data.Churn == "Yes")]
# df1 = pd.melt(df1[cols])
# df1.rename(columns={'value': 'Has service'}, inplace=True)
# ax = sns.countplot(data=df1, x='variable', hue='Has service', hue_order=['No', 'Yes'])
# ax.set(xlabel='Internet Additional service', ylabel='Churn Num')
# plt.rcParams.update({'font.size':20})
# plt.legend( labels = ['No Service', 'Has Service'],fontsize=15)
# plt.title('Num of Churn Customers as Internet Additional Service')
# plt.show()
# plt.figure(figsize=(12, 4.5))
# barplot_percentages("PaymentMethod",orient='h')
# g = sns.FacetGrid(data, col="PaperlessBilling", height=6, aspect=.9)
# ax = g.map(sns.barplot, "Contract", "churn_rate", palette = "Blues_d", order= ['Month-to-month', 'One year', 'Two year'])
# plt.rcParams.update({'font.size':18})
# plt.show()
# kdeplot('MonthlyCharges','MonthlyCharges')
# kdeplot('TotalCharges','TotalCharges')
# plt.show()
